package com.example.balneario.balneario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BalnearioApplicationTests {

	@Test
	void contextLoads() {
	}

}
