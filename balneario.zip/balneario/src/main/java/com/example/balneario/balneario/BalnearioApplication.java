package com.example.balneario.balneario;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BalnearioApplication {

	public static void main(String[] args) {
		SpringApplication.run(BalnearioApplication.class, args);
	}

}
