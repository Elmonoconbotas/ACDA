package com.example.paises.paises;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaisesApplicationTests {

	@Test
	void contextLoads() {
	}

}
