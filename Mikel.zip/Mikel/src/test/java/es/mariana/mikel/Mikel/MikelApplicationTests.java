package es.mariana.mikel.Mikel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MikelApplicationTests {

	@Test
	void contextLoads() {
	}

}
