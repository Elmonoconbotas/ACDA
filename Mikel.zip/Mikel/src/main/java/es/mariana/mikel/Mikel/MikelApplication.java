package es.mariana.mikel.Mikel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MikelApplication {

	public static void main(String[] args) {
		SpringApplication.run(MikelApplication.class, args);
	}

}
