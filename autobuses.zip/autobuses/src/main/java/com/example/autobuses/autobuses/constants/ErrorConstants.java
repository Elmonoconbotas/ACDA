package com.example.autobuses.autobuses.constants;

public class ErrorConstants {
    public static final Integer RESULT_OK = 0;
    public static final Integer PARAM_NULL = -2;
}
