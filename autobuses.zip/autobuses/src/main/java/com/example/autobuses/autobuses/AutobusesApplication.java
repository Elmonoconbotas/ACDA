package com.example.autobuses.autobuses;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutobusesApplication {

	public static void main(String[] args) {
		SpringApplication.run(AutobusesApplication.class, args);
	}

}
