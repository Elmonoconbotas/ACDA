package ACDA_UT4_1a1.model.dao;

import ACDA_UT4_1a1.model.entity.Pais;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IPaisDAO  extends JpaRepository<Pais, Integer> {



}
