package ACDA_UT4_1a1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AcdaUt41a1Application {

	public static void main(String[] args) {
		SpringApplication.run(AcdaUt41a1Application.class, args);
	}

}
