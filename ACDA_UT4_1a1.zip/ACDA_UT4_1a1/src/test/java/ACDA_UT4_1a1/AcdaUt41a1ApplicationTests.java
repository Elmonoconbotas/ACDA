package ACDA_UT4_1a1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AcdaUt41a1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
