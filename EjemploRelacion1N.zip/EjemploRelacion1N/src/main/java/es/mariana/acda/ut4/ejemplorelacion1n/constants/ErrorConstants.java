package es.mariana.acda.ut4.ejemplorelacion1n.constants;

public class ErrorConstants {
    public static final Integer RESULT_OK = 0;
    public static final Integer PARAM_NULL = -2;
}
