package es.mariana.acda.ut4.ejemplorelacion1n;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjemploRelacion1NApplication {

    public static void main(String[] args) {
        SpringApplication.run(EjemploRelacion1NApplication.class, args);
    }

}
