package dao;

import model.Partida;


public class PartidaDAO extends GenericDAOImpl<Partida, Integer> {
    public PartidaDAO() {
        super(Partida.class);
    }
}

