package constants;

public class PartidaConstans {
    public static final int RESULTADO_SIN_JUGAR = -1;
    public static final int RESULTADO_EMPATE = 0;
    public static final int RESULTADO_GANA_EQUIPO_1 = 1;
    public static final int RESULTADO_GANA_EQUIPO_2 = 2;
}
