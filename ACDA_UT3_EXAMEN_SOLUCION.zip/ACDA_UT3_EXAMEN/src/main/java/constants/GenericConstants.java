package constants;

public class GenericConstants {
    public static final Integer RESULTADO_OK = 0;
    public static final Integer ERROR_SQL_EXCEPTION = -1;
    public static final Integer ERROR_PARAM_NULL = -2;
}
